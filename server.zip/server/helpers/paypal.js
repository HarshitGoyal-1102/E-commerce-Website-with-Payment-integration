const paypal = require("paypal-rest-sdk");

paypal.configure({
  mode: "sandbox",
  client_id: "AZUYrIw-pSeBmRPkcShEkDAj57uU7Ms31p-JYCNw9kBDDKh59jbCXzH34gE8q0j1HqkZrPu8whDNz3tw",
  client_secret: "EKX_7cxtFzQxJyRSaFGWEL7GY8pZy7tXixJx0bms8y0BAsUJTGnP9WXb-yiMJT-DeiXLljxjwn915tqG",
});

module.exports = paypal;
